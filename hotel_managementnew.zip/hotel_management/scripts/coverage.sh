#!/usr/bin/env bash
# Runs the tests of a --coverage build and reports line/branch coverage for src/ and include/.
# (The plain-gcov fallback reports the .cpp files in src/ only.)
# Uses gcovr or lcov (HTML report) when installed; falls back to plain gcov text output.
# Usage: scripts/coverage.sh <build-dir>   (default: build/cov)
# Env:   COVERAGE_MIN=80  -> fail if line coverage is below 80%
set -euo pipefail

BUILD="${1:-build/cov}"
REPORT="$BUILD/report"
MIN="${COVERAGE_MIN:-0}"

find "$BUILD" -name '*.gcda' -delete      # forget earlier runs
"$BUILD/hotel_tests"
mkdir -p "$REPORT"

if command -v gcovr >/dev/null; then
    gcovr --root . --filter 'src/' --filter 'include/' --exclude-throw-branches \
          --print-summary --html-details "$REPORT/index.html" --fail-under-line "$MIN" "$BUILD"
    echo "HTML report: $REPORT/index.html"

elif command -v lcov >/dev/null; then
    lcov --capture --directory "$BUILD" --output-file "$REPORT/all.info" --quiet \
         --rc branch_coverage=1 --ignore-errors mismatch,inconsistent
    lcov --extract "$REPORT/all.info" "$PWD/src/*" "$PWD/include/*" --output-file "$REPORT/lcov.info" \
         --quiet --rc branch_coverage=1
    lcov --summary "$REPORT/lcov.info" --rc branch_coverage=1
    if command -v genhtml >/dev/null; then
        genhtml "$REPORT/lcov.info" --output-directory "$REPORT" --quiet --branch-coverage
        echo "HTML report: $REPORT/index.html"
    fi

else
    echo "(gcovr/lcov not installed - using plain gcov; 'pip install gcovr' gives an HTML report)"
    cd "$BUILD/report"
    : > summary.txt
    for gcda in $(find ../obj/src -name '*.gcda' | sort); do
        gcov -n -r -s "$OLDPWD" -o "$(dirname "$gcda")" "$gcda" 2>/dev/null \
            | awk -v root="$OLDPWD" '
                /^File/ { f=$2; gsub(/\x27/,"",f); keep = (f ~ /^src\//) }
                /^Lines executed/ && keep { print f, $2, $3, $4; keep = 0 }'
    done | sort -u > summary.txt
    printf '\n%-32s %s\n' "FILE" "LINE COVERAGE"
    awk '{ split($2,p,":"); pct=p[2]+0; printf "%-32s %s %s %s\n", $1, p[2], $3, $4; n=substr($4,1)+0; hit+=pct*$4/100; tot+=$4 }
         END { if (tot>0) printf "\nTOTAL: %.1f%% of %d lines\n", 100*hit/tot, tot }' summary.txt
    TOTAL=$(awk '{ split($2,p,":"); hit+=(p[2]+0)*$4/100; tot+=$4 } END { if (tot>0) printf "%.0f", 100*hit/tot; else print 0 }' summary.txt)
    if [ "$TOTAL" -lt "$MIN" ]; then echo "Coverage $TOTAL% is below required $MIN%" >&2; exit 1; fi
fi
