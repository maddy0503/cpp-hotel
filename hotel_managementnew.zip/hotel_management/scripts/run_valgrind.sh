#!/usr/bin/env bash
# Runs the unit tests and a scripted app session under valgrind.
# Usage: scripts/run_valgrind.sh <build-dir>   (default: build/debug)
set -euo pipefail

BUILD="${1:-build/debug}"
if ! command -v valgrind >/dev/null; then
    echo "valgrind not found. Install it (e.g. 'sudo apt install valgrind') or use 'make sanitize'." >&2
    exit 1
fi

VG="valgrind --leak-check=full --show-leak-kinds=definite,possible --errors-for-leak-kinds=definite,possible \
--track-origins=yes --error-exitcode=1 --quiet"

echo "== unit tests under valgrind =="
$VG "$BUILD/hotel_tests"

echo "== app session under valgrind =="
RUNNER="$VG" "$(dirname "$0")/run_app_session.sh" "$BUILD/hotel_app"

echo "valgrind: no memory errors or leaks"
