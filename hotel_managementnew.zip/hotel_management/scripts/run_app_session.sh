#!/usr/bin/env bash
# Feeds a scripted session to the real hotel app in a scratch directory.
# Usage: scripts/run_app_session.sh <path-to-hotel_app>
# Set RUNNER="valgrind --error-exitcode=1 ..." to run the app under a tool.
set -euo pipefail

APP="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
TOMORROW="$(date -d tomorrow +%F)"

cd "$WORK"   # the app stores its data in ./data
# register, availability, book, check in, add service, check out, find, list, exit
${RUNNER:-} "$APP" > session.log <<INPUT
1
Alice Smith
555-1234
2
$TOMORROW
2
0
0
3
1
$TOMORROW
2
1
101
4
1
7
1
250
5
1
8
alice
9
0
INPUT

grep -q "INVOICE" session.log || { echo "app session: no invoice printed"; cat session.log; exit 1; }
grep -q "Goodbye." session.log || { echo "app session: did not exit cleanly"; cat session.log; exit 1; }
echo "app session OK"
