#pragma once
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "hotel/models.hpp"
#include "hotel/room.hpp"

namespace hotel {

constexpr double GST_RATE = 0.12;

class Hotel {
public:
    explicit Hotel(std::string dataDir = "data") : dir_(std::move(dataDir)) {}

    // Persistence (storage.cpp)
    bool load();
    bool save() const;

    // Guests
    int registerGuest(std::string name, std::string phone);
    const Guest* findGuest(int id) const;
    std::vector<const Guest*> searchGuests(const std::string& name) const;

    // Rooms
    const std::vector<std::unique_ptr<Room>>& rooms() const { return rooms_; }
    const Room* findRoom(int number) const;
    bool isOccupiedToday(int roomNo) const;
    std::vector<const Room*> availableRooms(int startDay, int nights,
                                            std::optional<RoomType> filter,
                                            double maxPrice) const;

    // Bookings
    int book(int guestId, int roomNo, int startDay, int nights, std::string& err);
    bool checkIn(int bookingId, std::string& err);
    bool checkOut(int bookingId, std::string& invoice, std::string& err);
    bool cancel(int bookingId, std::string& err);
    bool addService(int bookingId, double amount, std::string& err);

    const Booking* findBooking(int id) const;
    std::vector<const Booking*> bookingsFor(int guestId) const;
    std::string invoiceFor(const Booking& b) const;

private:
    Booking* findBookingMut(int id);
    bool roomFree(int roomNo, int startDay, int endDay) const;
    void resetDefaults();

    std::string dir_;
    std::vector<std::unique_ptr<Room>> rooms_;
    std::vector<Guest> guests_;
    std::vector<Booking> bookings_;
    int nextGuestId_ = 1;
    int nextBookingId_ = 1;
};

}  // namespace hotel
