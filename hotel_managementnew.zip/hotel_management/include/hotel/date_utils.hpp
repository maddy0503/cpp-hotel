#pragma once
#include <optional>
#include <string>

namespace hotel {

// A date is stored as a day number (days since 1970-01-01).
int daysFromCivil(int y, int m, int d);
std::string dayToString(int day);                   // "YYYY-MM-DD"
std::optional<int> parseDate(const std::string& s);  // "YYYY-MM-DD", nullopt if invalid
int todayDay();

}  // namespace hotel
