# Hotel Management System

A small C++20 console application for managing guests, rooms and bookings
(check-in, check-out, services, GST invoices). Data is stored in plain text
files under `data/`.

## Layout

```
app/main.cpp              entry point (wires Hotel + Cli to stdin/stdout)
include/hotel/            public headers
  date_utils.hpp            date <-> day-number helpers
  room.hpp                  Room hierarchy + factory
  models.hpp                Guest, Booking, BookingStatus
  hotel.hpp                 Hotel: all business rules
  cli/                      InputReader (validated prompts), Cli (menu)
src/                      implementation (built into libhotel.a)
  storage.cpp               Hotel::load / Hotel::save
  cli/                      menu + input code
tests/                    GoogleTest suite (one file per module)
scripts/                  coverage.sh, run_valgrind.sh, run_app_session.sh
data/                     runtime data (rooms/guests/bookings .txt)
```

Business logic (`Hotel`) knows nothing about the console, and the console code
takes injected streams, so everything can be tested without touching stdin/stdout.
Tests use temporary directories and never modify `data/`.

## Commands

| Command          | What it does                                                        |
|------------------|---------------------------------------------------------------------|
| `make` / `make run` | build / run the app                                              |
| `make test`      | build and run the GoogleTest suite                                  |
| `make coverage`  | tests with gcov; HTML report in `build/cov/report/` if gcovr/lcov is installed |
| `make valgrind`  | tests + a scripted app session under valgrind (fails on any error or leak) |
| `make sanitize`  | same idea using AddressSanitizer + UBSan (no valgrind needed)       |
| `make clean`     | remove `build/`                                                     |

`COVERAGE_MIN=90 make coverage` fails the build when line coverage drops below 90%.

## Requirements

```
sudo apt install g++ make libgtest-dev valgrind gcovr   # gcovr is optional (HTML report)
```
On Ubuntu/Debian 22.04+ `libgtest-dev` already ships the compiled libraries.
