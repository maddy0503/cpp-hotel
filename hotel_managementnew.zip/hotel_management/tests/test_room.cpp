#include <gtest/gtest.h>

#include "hotel/models.hpp"
#include "hotel/room.hpp"

using namespace hotel;

namespace {
struct Expected {
    RoomType type;
    const char* name;
    double price;
    int capacity;
};
}  // namespace

TEST(Room, FactoryBuildsEveryType) {
    const Expected table[] = {
        {RoomType::Single, "Single", 1500, 1},
        {RoomType::Double, "Double", 2500, 2},
        {RoomType::Deluxe, "Deluxe", 4000, 3},
        {RoomType::Suite, "Suite", 7000, 4},
    };
    int number = 100;
    for (const auto& e : table) {
        auto room = makeRoom(e.type, ++number);
        ASSERT_NE(room, nullptr) << e.name;
        EXPECT_EQ(room->number(), number);
        EXPECT_EQ(room->type(), e.type);
        EXPECT_EQ(room->typeName(), e.name);
        EXPECT_DOUBLE_EQ(room->pricePerNight(), e.price);
        EXPECT_EQ(room->capacity(), e.capacity);
    }
}

TEST(Room, FactoryReturnsNullForUnknownType) {
    EXPECT_EQ(makeRoom(static_cast<RoomType>(99), 1), nullptr);
}

TEST(Room, PricesAndCapacityGrowWithRoomClass) {
    double lastPrice = 0;
    int lastCap = 0;
    for (auto t : {RoomType::Single, RoomType::Double, RoomType::Deluxe, RoomType::Suite}) {
        auto r = makeRoom(t, 1);
        EXPECT_GT(r->pricePerNight(), lastPrice);
        EXPECT_GT(r->capacity(), lastCap);
        lastPrice = r->pricePerNight();
        lastCap = r->capacity();
    }
}

TEST(Models, StatusNames) {
    EXPECT_STREQ(statusName(BookingStatus::Booked), "Booked");
    EXPECT_STREQ(statusName(BookingStatus::CheckedIn), "Checked in");
    EXPECT_STREQ(statusName(BookingStatus::CheckedOut), "Checked out");
    EXPECT_STREQ(statusName(BookingStatus::Cancelled), "Cancelled");
    EXPECT_STREQ(statusName(static_cast<BookingStatus>(42)), "?");
}

TEST(Models, BookingEndDayIsStartPlusNights) {
    Booking b{1, 1, 101, 100, 3, BookingStatus::Booked, 0.0};
    EXPECT_EQ(b.endDay(), 103);
}
