#include <gtest/gtest.h>

#include <fstream>

#include "hotel/hotel.hpp"
#include "test_support.hpp"

using namespace hotel;

TEST(Storage, FirstLoadCreatesDataFilesWithDefaultRooms) {
    test::TempDir dir;
    Hotel h(dir.str());
    ASSERT_TRUE(h.load());
    EXPECT_TRUE(std::filesystem::exists(dir.file("rooms.txt")));
    EXPECT_TRUE(std::filesystem::exists(dir.file("guests.txt")));
    EXPECT_TRUE(std::filesystem::exists(dir.file("bookings.txt")));
    EXPECT_EQ(h.rooms().size(), 9u);
    EXPECT_NE(dir.read("rooms.txt").find("401|3"), std::string::npos);
}

TEST(Storage, DataSurvivesSaveAndReload) {
    test::TempDir dir;
    std::string err;
    {
        Hotel h(dir.str());
        ASSERT_TRUE(h.load());
        int g = h.registerGuest("Alice Smith", "555-1234");
        int b = h.book(g, 201, test::tomorrow(), 3, err);
        ASSERT_GT(b, 0) << err;
        ASSERT_TRUE(h.checkIn(b, err));
        ASSERT_TRUE(h.addService(b, 123.45, err));
        ASSERT_TRUE(h.save());
    }
    Hotel h(dir.str());
    ASSERT_TRUE(h.load());
    ASSERT_NE(h.findGuest(1), nullptr);
    EXPECT_EQ(h.findGuest(1)->name, "Alice Smith");
    EXPECT_EQ(h.findGuest(1)->phone, "555-1234");
    const Booking* b = h.findBooking(1);
    ASSERT_NE(b, nullptr);
    EXPECT_EQ(b->roomNo, 201);
    EXPECT_EQ(b->nights, 3);
    EXPECT_EQ(b->status, BookingStatus::CheckedIn);
    EXPECT_DOUBLE_EQ(b->services, 123.45);

    // IDs continue where they left off.
    EXPECT_EQ(h.registerGuest("Bob", "1"), 2);
    EXPECT_EQ(h.book(2, 202, test::tomorrow(), 1, err), 2);
}

TEST(Storage, CustomRoomLayoutIsRespected) {
    test::TempDir dir;
    dir.write("rooms.txt", "500|1\n501|3\n");
    Hotel h(dir.str());
    ASSERT_TRUE(h.load());
    ASSERT_EQ(h.rooms().size(), 2u);
    EXPECT_EQ(h.findRoom(500)->type(), RoomType::Double);
    EXPECT_EQ(h.findRoom(501)->type(), RoomType::Suite);
    EXPECT_EQ(h.findRoom(101), nullptr);
}

TEST(Storage, MalformedRoomLinesAreSkipped) {
    test::TempDir dir;
    dir.write("rooms.txt", "justtext\n12|9\nabc|1\n77|-1\n301|2\n");
    Hotel h(dir.str());
    ASSERT_TRUE(h.load());
    ASSERT_EQ(h.rooms().size(), 1u);
    EXPECT_EQ(h.rooms()[0]->number(), 301);
}

TEST(Storage, UnusableRoomFileFallsBackToDefaults) {
    test::TempDir dir;
    dir.write("rooms.txt", "garbage\n\n");
    Hotel h(dir.str());
    ASSERT_TRUE(h.load());
    EXPECT_EQ(h.rooms().size(), 9u);
}

TEST(Storage, MalformedGuestAndBookingLinesAreSkipped) {
    test::TempDir dir;
    dir.write("guests.txt", "1|Alice|555\nbad\nx|Bob|1\n5|Carol|2\n");
    dir.write("bookings.txt",
              "1|1|101|20000|2|0|0.00\n"   // ok
              "short|line\n"
              "2|1|101|20000|2|9|0.00\n"   // status out of range
              "3|1|101|oops|2|0|0.00\n"    // not a number
              "4|5|102|20010|1|1|75.50\n"  // ok
    );
    Hotel h(dir.str());
    ASSERT_TRUE(h.load());
    EXPECT_NE(h.findGuest(1), nullptr);
    EXPECT_NE(h.findGuest(5), nullptr);
    EXPECT_EQ(h.findGuest(2), nullptr);
    EXPECT_NE(h.findBooking(1), nullptr);
    EXPECT_EQ(h.findBooking(2), nullptr);
    EXPECT_EQ(h.findBooking(3), nullptr);
    ASSERT_NE(h.findBooking(4), nullptr);
    EXPECT_DOUBLE_EQ(h.findBooking(4)->services, 75.5);

    // Next IDs are one past the highest id seen.
    EXPECT_EQ(h.registerGuest("New", "0"), 6);
}

TEST(Storage, SaveWritesBookingsWithTwoDecimalServices) {
    test::TempDir dir;
    Hotel h(dir.str());
    ASSERT_TRUE(h.load());
    std::string err;
    int g = h.registerGuest("A", "1");
    int b = h.book(g, 101, test::tomorrow(), 1, err);
    ASSERT_TRUE(h.checkIn(b, err));
    ASSERT_TRUE(h.addService(b, 10, err));
    ASSERT_TRUE(h.save());
    EXPECT_NE(dir.read("bookings.txt").find("|1|10.00"), std::string::npos);
}

TEST(Storage, LoadFailsWhenDataPathIsAFile) {
    test::TempDir dir;
    dir.write("blocker", "not a directory");
    Hotel h((dir.file("blocker")).string());
    EXPECT_FALSE(h.load());
}

TEST(Storage, SaveFailsWhenDirectoryDisappears) {
    test::TempDir dir;
    Hotel h(dir.str());
    ASSERT_TRUE(h.load());
    std::filesystem::remove_all(dir.file(""));
    EXPECT_FALSE(h.save());
}
