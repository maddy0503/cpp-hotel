#include "hotel/date_utils.hpp"

#include <cstdio>
#include <ctime>

namespace hotel {

int daysFromCivil(int y, int m, int d) {
    y -= m <= 2;
    const int era = (y >= 0 ? y : y - 399) / 400;
    const unsigned yoe = static_cast<unsigned>(y - era * 400);
    const unsigned doy = static_cast<unsigned>((153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1);
    const unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return era * 146097 + static_cast<int>(doe) - 719468;
}

static void civilFromDays(int z, int& y, int& m, int& d) {
    z += 719468;
    const int era = (z >= 0 ? z : z - 146096) / 146097;
    const unsigned doe = static_cast<unsigned>(z - era * 146097);
    const unsigned yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    y = static_cast<int>(yoe) + era * 400;
    const unsigned doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    const unsigned mp = (5 * doy + 2) / 153;
    d = static_cast<int>(doy - (153 * mp + 2) / 5 + 1);
    m = static_cast<int>(mp < 10 ? mp + 3 : mp - 9);
    y += (m <= 2);
}

std::string dayToString(int day) {
    int y, m, d;
    civilFromDays(day, y, m, d);
    char buf[48];
    std::snprintf(buf, sizeof buf, "%04d-%02d-%02d", y, m, d);
    return buf;
}

std::optional<int> parseDate(const std::string& s) {
    int y, m, d;
    if (s.size() != 10 || std::sscanf(s.c_str(), "%d-%d-%d", &y, &m, &d) != 3) return std::nullopt;
    int day = daysFromCivil(y, m, d);
    if (dayToString(day) != s) return std::nullopt;  // rejects 2030-02-31 etc.
    return day;
}

int todayDay() {
    std::time_t t = std::time(nullptr);
    std::tm* lt = std::localtime(&t);
    return daysFromCivil(lt->tm_year + 1900, lt->tm_mon + 1, lt->tm_mday);
}

}  // namespace hotel
