#include <filesystem>
#include <fstream>
#include <iomanip>

#include "hotel/hotel.hpp"

namespace hotel {

static std::vector<std::string> split(const std::string& line, char sep) {
    std::vector<std::string> out;
    std::string cur;
    for (char c : line) {
        if (c == sep) { out.push_back(cur); cur.clear(); }
        else cur += c;
    }
    out.push_back(cur);
    return out;
}

bool Hotel::load() {
    namespace fs = std::filesystem;
    std::error_code ec;
    fs::create_directories(dir_, ec);
    if (ec) return false;  // e.g. the path is a file or not writable
    rooms_.clear();
    guests_.clear();
    bookings_.clear();
    nextGuestId_ = nextBookingId_ = 1;

    std::string line;
    {
        std::ifstream in(dir_ + "/rooms.txt");
        while (std::getline(in, line)) {
            auto f = split(line, '|');
            if (f.size() < 2) continue;
            try {
                int type = std::stoi(f[1]);
                if (type < 0 || type > 3) continue;
                rooms_.push_back(makeRoom(static_cast<RoomType>(type), std::stoi(f[0])));
            } catch (...) {}
        }
    }
    if (rooms_.empty()) resetDefaults();

    {
        std::ifstream in(dir_ + "/guests.txt");
        while (std::getline(in, line)) {
            auto f = split(line, '|');
            if (f.size() < 3) continue;
            try {
                Guest g{std::stoi(f[0]), f[1], f[2]};
                guests_.push_back(g);
                if (g.id >= nextGuestId_) nextGuestId_ = g.id + 1;
            } catch (...) {}
        }
    }
    {
        std::ifstream in(dir_ + "/bookings.txt");
        while (std::getline(in, line)) {
            auto f = split(line, '|');
            if (f.size() < 7) continue;
            try {
                int st = std::stoi(f[5]);
                if (st < 0 || st > 3) continue;
                Booking b{std::stoi(f[0]), std::stoi(f[1]), std::stoi(f[2]), std::stoi(f[3]),
                          std::stoi(f[4]), static_cast<BookingStatus>(st), std::stod(f[6])};
                bookings_.push_back(b);
                if (b.id >= nextBookingId_) nextBookingId_ = b.id + 1;
            } catch (...) {}
        }
    }
    return save();  // creates the files on first run
}

bool Hotel::save() const {
    std::ofstream rf(dir_ + "/rooms.txt"), gf(dir_ + "/guests.txt"), bf(dir_ + "/bookings.txt");
    if (!rf || !gf || !bf) return false;
    for (const auto& r : rooms_) rf << r->number() << '|' << static_cast<int>(r->type()) << '\n';
    for (const auto& g : guests_) gf << g.id << '|' << g.name << '|' << g.phone << '\n';
    bf << std::fixed << std::setprecision(2);
    for (const auto& b : bookings_)
        bf << b.id << '|' << b.guestId << '|' << b.roomNo << '|' << b.startDay << '|' << b.nights
           << '|' << static_cast<int>(b.status) << '|' << b.services << '\n';
    return true;
}

}  // namespace hotel
