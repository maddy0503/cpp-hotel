#include "hotel/hotel.hpp"

#include <cctype>
#include <iomanip>
#include <sstream>

#include "hotel/date_utils.hpp"

namespace hotel {

// ---------- rooms ----------
void Hotel::resetDefaults() {
    rooms_.clear();
    for (int n : {101, 102, 103}) rooms_.push_back(makeRoom(RoomType::Single, n));
    for (int n : {201, 202, 203}) rooms_.push_back(makeRoom(RoomType::Double, n));
    for (int n : {301, 302})      rooms_.push_back(makeRoom(RoomType::Deluxe, n));
    rooms_.push_back(makeRoom(RoomType::Suite, 401));
}

const Room* Hotel::findRoom(int number) const {
    for (const auto& r : rooms_)
        if (r->number() == number) return r.get();
    return nullptr;
}

// ---------- guests ----------
static std::string clean(std::string s) {
    for (char& c : s)
        if (c == '|' || c == '\n' || c == '\r') c = ' ';
    return s;
}

int Hotel::registerGuest(std::string name, std::string phone) {
    guests_.push_back({nextGuestId_, clean(std::move(name)), clean(std::move(phone))});
    return nextGuestId_++;
}

const Guest* Hotel::findGuest(int id) const {
    for (const auto& g : guests_)
        if (g.id == id) return &g;
    return nullptr;
}

static std::string lower(std::string s) {
    for (char& c : s) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return s;
}

std::vector<const Guest*> Hotel::searchGuests(const std::string& name) const {
    std::vector<const Guest*> out;
    const std::string key = lower(name);
    for (const auto& g : guests_)
        if (lower(g.name).find(key) != std::string::npos) out.push_back(&g);
    return out;
}

// ---------- availability ----------
bool Hotel::roomFree(int roomNo, int startDay, int endDay) const {
    for (const auto& b : bookings_) {
        if (b.roomNo != roomNo) continue;
        if (b.status != BookingStatus::Booked && b.status != BookingStatus::CheckedIn) continue;
        if (startDay < b.endDay() && b.startDay < endDay) return false;
    }
    return true;
}

std::vector<const Room*> Hotel::availableRooms(int startDay, int nights,
                                               std::optional<RoomType> filter,
                                               double maxPrice) const {
    std::vector<const Room*> out;
    for (const auto& r : rooms_) {
        if (filter && r->type() != *filter) continue;
        if (maxPrice > 0 && r->pricePerNight() > maxPrice) continue;
        if (roomFree(r->number(), startDay, startDay + nights)) out.push_back(r.get());
    }
    return out;
}

bool Hotel::isOccupiedToday(int roomNo) const {
    for (const auto& b : bookings_)
        if (b.roomNo == roomNo && b.status == BookingStatus::CheckedIn) return true;
    return false;
}

// ---------- bookings ----------
Booking* Hotel::findBookingMut(int id) {
    for (auto& b : bookings_)
        if (b.id == id) return &b;
    return nullptr;
}

const Booking* Hotel::findBooking(int id) const {
    for (const auto& b : bookings_)
        if (b.id == id) return &b;
    return nullptr;
}

std::vector<const Booking*> Hotel::bookingsFor(int guestId) const {
    std::vector<const Booking*> out;
    for (const auto& b : bookings_)
        if (b.guestId == guestId) out.push_back(&b);
    return out;
}

int Hotel::book(int guestId, int roomNo, int startDay, int nights, std::string& err) {
    if (!findGuest(guestId)) { err = "No guest with that ID."; return -1; }
    if (!findRoom(roomNo)) { err = "No such room."; return -1; }
    if (nights < 1) { err = "Stay must be at least 1 night."; return -1; }
    if (startDay < todayDay()) { err = "Check-in date is in the past."; return -1; }
    if (!roomFree(roomNo, startDay, startDay + nights)) {
        err = "Room is already booked for those dates.";
        return -1;
    }
    bookings_.push_back({nextBookingId_, guestId, roomNo, startDay, nights, BookingStatus::Booked, 0.0});
    return nextBookingId_++;
}

bool Hotel::checkIn(int bookingId, std::string& err) {
    Booking* b = findBookingMut(bookingId);
    if (!b) { err = "No booking with that ID."; return false; }
    if (b->status != BookingStatus::Booked) {
        err = std::string("Booking is ") + statusName(b->status) + ", cannot check in.";
        return false;
    }
    if (isOccupiedToday(b->roomNo)) { err = "Room is still occupied by another guest."; return false; }
    b->status = BookingStatus::CheckedIn;
    return true;
}

bool Hotel::addService(int bookingId, double amount, std::string& err) {
    Booking* b = findBookingMut(bookingId);
    if (!b) { err = "No booking with that ID."; return false; }
    if (b->status != BookingStatus::CheckedIn) { err = "Services can only be added while checked in."; return false; }
    if (amount <= 0) { err = "Amount must be positive."; return false; }
    b->services += amount;
    return true;
}

bool Hotel::cancel(int bookingId, std::string& err) {
    Booking* b = findBookingMut(bookingId);
    if (!b) { err = "No booking with that ID."; return false; }
    if (b->status != BookingStatus::Booked) {
        err = std::string("Booking is ") + statusName(b->status) + ", cannot cancel.";
        return false;
    }
    b->status = BookingStatus::Cancelled;
    return true;
}

bool Hotel::checkOut(int bookingId, std::string& invoice, std::string& err) {
    Booking* b = findBookingMut(bookingId);
    if (!b) { err = "No booking with that ID."; return false; }
    if (b->status != BookingStatus::CheckedIn) {
        err = std::string("Booking is ") + statusName(b->status) + ", cannot check out.";
        return false;
    }
    b->status = BookingStatus::CheckedOut;
    invoice = invoiceFor(*b);
    return true;
}

std::string Hotel::invoiceFor(const Booking& b) const {
    // Data files can be edited by hand, so tolerate a missing guest or room
    // instead of dereferencing a null pointer.
    const Guest* g = findGuest(b.guestId);
    const Room* r = findRoom(b.roomNo);
    const double nightly = r ? r->pricePerNight() : 0.0;
    const double roomCharge = b.nights * nightly;
    const double subtotal = roomCharge + b.services;
    const double tax = subtotal * GST_RATE;
    const std::string roomLine = "Room: " + std::to_string(b.nights) + " night(s) x " +
                                 std::to_string(static_cast<int>(nightly));

    std::ostringstream o;
    o << std::fixed << std::setprecision(2);
    auto line = [&](const std::string& label, double v) {
        o << std::left << std::setw(34) << label << std::right << std::setw(12) << v << "\n";
    };
    o << "\n==================== INVOICE ====================\n"
      << "Booking #" << b.id << "   Guest: " << (g ? g->name : "?") << " (ID " << b.guestId << ")\n"
      << "Room " << b.roomNo << " (" << (r ? r->typeName() : "?") << ")  "
      << dayToString(b.startDay) << " to " << dayToString(b.endDay()) << "\n"
      << "-------------------------------------------------\n";
    line(roomLine, roomCharge);
    line("Services", b.services);
    line("Subtotal", subtotal);
    line("GST (12%)", tax);
    o << "-------------------------------------------------\n";
    line("TOTAL (Rs.)", subtotal + tax);
    o << "=================================================\n";
    return o.str();
}

}  // namespace hotel
