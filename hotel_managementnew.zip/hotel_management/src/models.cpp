#include "hotel/models.hpp"

namespace hotel {

const char* statusName(BookingStatus s) {
    switch (s) {
        case BookingStatus::Booked:     return "Booked";
        case BookingStatus::CheckedIn:  return "Checked in";
        case BookingStatus::CheckedOut: return "Checked out";
        case BookingStatus::Cancelled:  return "Cancelled";
    }
    return "?";
}

}  // namespace hotel
